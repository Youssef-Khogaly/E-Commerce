create definer = root@localhost trigger afterUserInsert
    after insert
    on customer
    for each row
begin
        insert into cart(cart_id , subTotalInCents)values (NEW.cust_id,0);
    END;

